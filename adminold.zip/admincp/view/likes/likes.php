<?php
class likes extends config{

	public function likes_list(){ ?>
    
    <style>
	.img_tbl{
	text-align: center;
    border-radius: 5px;
    height: 100px;
    border: 5px solid #ccc;
	}
	</style>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.9/css/jquery.dataTables.min.css"/>
	 
<script type="text/javascript" src="https://cdn.datatables.net/1.10.9/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/plug-ins/1.10.16/pagination/input.js"></script>

  
  
  


	<div class="content">
		
		<div class="nav">
		Ads Management
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  class="div-custom">
       <div class="container" >
	
<a href="ads_export.php">Export Ads</a> &nbsp;&nbsp;&nbsp;&nbsp;
<a href="field_export.php">Export Ads Fields</a>

	<table id="employee_grid" class="display">
    <thead>
  <tr>
  
  <th ><div align="center"><strong>S.No</strong></div></th>
  <th><div align="left"><strong>Ads ID</strong></div></th>
  <th><div align="left"><strong>Ads Name</strong></div></th>
  <th><div align="left"><strong>Customer Name</strong></div></th>
    <th><div align="left"><strong>Customer Email</strong></div></th>
    <th><div align="center"><strong>Customer Mobile</strong></div></th>
    <th  align="center"><div align="left"><strong>Contact No</strong></div></th>
	
  </tr>
  </thead>
  
  
</table>
</div>
<script type="text/javascript">
$( document ).ready(function() {
$('#employee_grid').DataTable({
scrollY:        "800px",
        scrollX:        true,
        scrollCollapse: true,
"columnDefs": [
            { width: '20%', targets: 0 }
        ],
        "fixedColumns": true,
		"pagingType": "input",
				 "bProcessing": true,
				 "Processing": true,
         "serverSide": true,
         "ajax":{
            url :"responselikes.php", // json datasource
            type: "post",  // type of method  ,GET/POST/DELETE
            error: function(){
              $("#employee_grid_processing").css("display","none");
            }
          }
        });   
});
</script>

</div>
</div>
</div>
	
		

	<?php
	}

}
?>
	
