<?php
class privacy extends config{

	
	
	public function categoryList(){ ?>
	
	    <div class="content">
		
		<div class="nav">
		Privacy Management
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="background-color:#CCCCCC; padding:10px; width:100%; border-color:#fed82e;border-style:dashed;border-width:thin;border-radius:5px;">
	<style type="text/css">
   #rows tr>th{
	padding:5px;
	border-style:solid;
	border-width:thin;
	border-color:#999999;
   }
   #rows tr>td{
	padding:5px;
	border-style:solid;
	border-width:thin;
	border-color:#999999;
   }
   a{
	text-decoration:none;
	}
   </style>
	<table id="rows" width="100%" border="0">
  <tr>
    <td width="5%"><strong>No</strong></td>
    <td width="30%"><strong>Category Name</strong></td>
    <td width="10%" align="center"><strong>Privacy</strong></td>
    <td width="10%" align="center"><strong>Status</strong></td>
    <td width="20%" colspan="3" align="center"><strong>Action</strong></td>
  </tr>
  <?php
  $customer_query = mysqli_query($this->mysqlConfig(),"select * from pic_categories");
  $no = 1;
  while($row = mysqli_fetch_array($customer_query)){?>
  
  <tr>
    <td><?php echo $no; ?></td>
    <td><?php echo $row['categories_name']; ?></td>
    <td align="center"><div class="link_href"><a href="#">Set Privacy</a></div></td>
   
    <td align="center"><?php if($row['categories_status']==1){ ?> <div class="link_href"><a href="#">Deactive</a></div>  <?php } else { ?> <div class="link_href"><a href="#">active</a></div><?php } ?></td>
    <td align="center"><div class="link_href"><a href="index.php?action=view&module=categorys&id=<?php echo $row['categories_id']; ?>">View</a></div></td>
    <td align="center"><div class="link_href"><a href="index.php?action=view&module=editcategory&id=<?php echo $row['categories_id']; ?>">Edit</a></div></td>
    <td align="center"><div class="link_href"><a href="index.php?action=view&module=delcategorys&id=<?php echo $row['categories_id']; ?>">Terminate</a></div></td>
  </tr>
  
  
 <?php 
 $no++;
 }
  ?>
</table>

</div>
</div>
</div>
	
    <?php
    }
	
	

}
?>