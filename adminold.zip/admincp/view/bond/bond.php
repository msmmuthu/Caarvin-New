<?php

class bond extends config{

public function age($date){
	$year_diff = '';
	$time = strtotime($date);

	if(FALSE === $time){
		return '';
	}

	$date = date('Y-m-d', $time);
	$year = date('Y', $time);
	$month = date('m', $time);
	$day = date('d', $time);
	
	list($year,$month,$day) = explode("-",$date);
	$year_diff = date("Y")-$year;
	$month_diff = date("m")-$month;
	$day_diff = date("d")-$day;
	if ($day_diff < 0 || $month_diff < 0) $year_diff;

	return $year_diff;
}

public function form(){
?>
<?php
$customer_query = mysqli_query($this->mysqlConfig(),"select * from registration where cusid = ".$_REQUEST['cid']."");
$customer_row = mysqli_fetch_object($customer_query);
?>
<div style="width:881px; float:left; margin:10px 0 0 53px; padding:12px 0 0 57px;background-image:url(css/images/star.jpg);height: 875px;">
	<div >
			<div style="width:100%; float:left;">
				<div style="width: 388px;height: 112px;float: left;padding: 0px;margin: 145px 0 0 60px;"><textarea name="info" style="width: 98%;
	height: 95%;"> <?php echo $customer_row->cus_name.",".$customer_row->cus_address; ?>
   </textarea></div>
				<div style="width:200px; height:20px; float:left; padding:15px; margin:150px 0px 0px 125px;"><input type="text" name="issueno" style="margin: 0px 0px 0px 15px;width: 200px;height: 25px;" value="<?php echo $customer_row->cus_reg_date; ?>" /></div>
				<!--<div style="width:200px; height:17px; float:left; padding:15px; margin:1px 0px 0px 124px;"><input type="text" name="sno" style="margin: 0px 0px 0px 15px;width: 200px;height: 25px;" /></div>-->
			</div>
				<div style="width:100%; float:left;">
				<div style="width:198px; height: 36px; float:left; padding:10px; margin:170px 0 0 55px;"><input name="regno" type="text" style="width: 200px;height: 25px;" value="<?php echo $customer_row->cus_regi_no." & ".$customer_row->cus_reg_date; ?>"></div>
				<div style="width:94px; height: 36px; float:left; padding:10px; margin:170px 0 0 0px;"><input name="plan_no" type="text" style="width: 95px;height: 25px;" value="<?php echo $customer_row->cus_payment_plan."st & ".$customer_row->cus_plan_term."Month"; ?>"></div>
				<div style="width:91px; height: 36px; float:left; padding:10px; margin:170px 0 0 0px;"><input name="p_size" type="text" style="width: 95px;height: 25px;" value="<?php echo $customer_row->cus_consideration_plotsize; ?>"></div>
				<div style="width:91px; height: 36px; float:left; padding:10px; margin:170px 0 0 0px;"><input name="m_pay" type="text" style="width: 95px;height: 25px;" value="<?php echo $customer_row->cus_payment_mode; ?>"></div>
				<div style="width:91px; height: 36px; float:left; padding:10px; margin:170px 0 0 0px;"><input name="instal" type="text" style="width: 95px;height: 25px;"></div>
				<div style="width:91px; height: 36px; float:left; padding:10px; margin:170px 0 0 0px;"><input name="e_date" type="text" style="width: 95px;height: 25px;" value="<?php echo $customer_row->cus_agreement_expirydate; ?>"></div>
			</div>
				<div style="width:100%; float:left;">
				<div style="width: 573px; height:17px; float:left; padding:8px; margin:1px 0 0 238px; "><input name="day_pi" type="text" style="width: 200px;height: 20px;"></div>
				<div style="width:236px; height: 36px; float:left; padding:0px; margin:15px 0 0 150px;"><input name="rno" type="text" style="width: 200px;height: 25px;"></div>
				<div style="width: 40px;height: 36px;float: left;padding: 10px;margin: 5px 0 0 78px; "><input name="cage" type="text" style="width: 45px;height: 25px;"  value="<?php echo $this->age($customer_row->cus_dob); ?>"></div>
				<div style="width:178px; height: 36px; float:left; padding:10px; margin:5px 0 0 110px;"><input name="amount" type="text" style="width: 160px;height: 25px;" value="<?php echo $customer_row->cus_instalment_amt; ?>"></div>
				<div style="width: 315px; height:20px; float:left; padding:0px; margin:4px 0 0 150px;"><input name="name" type="text" style="width: 200px;height: 25px;" value="<?php echo $customer_row->cus_nomine_name; ?>"></div>
				<div style="width: 123px;height: 20px;float: left;margin: 4px 0 0 232px;"><input name="er_value" type="text" style="width: 95px;height: 25px;" value="<?php echo $customer_row->cus_estimate_value; ?>"></div>
				<div style="width:301px; height: 17px; float:left; padding:0px; margin:18px 0 0 150px;"><input name="nage" type="text" style="width: 200px;height: 25px;" value="<?php echo $this->age($customer_row->cus_nomine_dob); ?>"></div>
                
				
				<div style="width: 254px; height:20px; float:left; padding:8px; margin:9px 0 0 110px;"><input name="relation" type="text" style="width: 200px;height: 25px;" value="<?php echo $customer_row->cus_nomine_relationship; ?>"></div>
				<div style="width:301px; height: 14px; float:left; padding:0px; margin:8px 0 0 150px;"><input name="acode" type="text" style="width: 200px;height: 25px;" value="<?php echo $customer_row->cus_agency_reg_no; ?>"></div>
			 
				<div style="width:249px; height: 13px; float:left; padding:10px; margin:0px 0px 0px 108px"><input name="ucode" type="text" style="width: 200px;height: 25px;"></div>
			   
	   
			</div>
				 <div style="width:100%; float:left;">
				 <div style="width:342px; height: 78px; float:left; padding:21px; margin:42px 0px 0px 52px;"><textarea name="add" style="width: 290px;height: 65px;"></textarea></div>
			 </div>
			 
			 
			 
		</div>
	</div>
<?php
}

}
?>