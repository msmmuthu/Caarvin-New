<?php
class customers extends config{

public function customerList_privacy(){ 

?>
	
	    <div class="content">
		
		<div class="nav"  style="width: 100%; height:auto;">
		Customer Management Privacy Setting
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="background-color:#CCCCCC; padding:10px; width:100%; border-color:#fed82e;border-style:dashed;border-width:thin;border-radius:5px;">
       <div align="left"><a class="btn_sub_active" href="index.php?action=view&module=customer">List</a></div>
       <div align="left"><a class="btn_sub" href="index.php?action=view&module=user&post=user">Add</a></div>
	<style type="text/css">
   #rows tr>th{
	padding:5px;
	border-style:solid;
	border-width:thin;
	border-color:#999999;
   }
   #rows tr>td{
	padding:5px;
	border-style:solid;
	border-width:thin;
	border-color:#999999;
   }
   a{
	text-decoration:none;
	}
   </style>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" name="cat_pri" id="cat_pri" method="post" >
    <?php 
    $query = mysqli_query($this->mysqlConfig(),"select * from pic_user where user_id=".$_GET['id']." limit 1");
	$row_user = mysqli_fetch_array($query );
	?>
	
    <?php
   
    ?>
	<table id="rows" width="100%" border="0">
  <tr>
    <td ><strong>Category</strong></td>
    <td >
	<?php 
	 $customer_query = mysqli_query($this->mysqlConfig(),"select * from pic_categories where categories_parent=0");
	?>
	<select name="cat[]" size="10" multiple class="form_txt" id="cat"  >
	<?php 
	while($row = mysqli_fetch_array($customer_query)){?>
	?>
                    <option <?php if(strpos($row_user ['privacy_category'], $row['categories_id']) !== false){ ?> selected="selected" <?php } ?> value="<?php echo $row['categories_id']; ?>" ><?php echo $row['categories_name']; ?></option>
<?php 
	}
	?>
			  </select>
			</td></tr>
			
              <tr>
    <td ><strong>Taluk</strong></td>
	<td ><?php $customer_query1 = mysqli_query($this->mysqlConfig(),"select distinct city2 from pic_geometric");
	?>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/bootstrap-select.min.css" />
    
  <script src="js/bootstrap.min.js"></script>
  <script src="js/bootstrap-select.min.js"></script>
    
            
            
            <div class="form-group">
            <select data-live-search="true" class="selectpicker" name="loc[]" size="10" multiple="multiple" id="loc">
				<?php 
                while($row1 = mysqli_fetch_array($customer_query1)){?>
                ?>
                <option  data-tokens="<?php echo $row1['city2']; ?>" <?php if(strpos($row_user ['privacy_location'], $row1['city2']) !== false){ ?> selected="selected" <?php } ?> value="<?php echo $row1['city2']; ?>" > <?php echo $row1['city2']; ?></option>
                <?php 
                }
                ?>
            </select>
            </div>


            
	</td></tr>
    <tr>
   <td ><strong>Allow Signup</strong></td>
	<td>
             
             
           
             <input type="radio" name="register" id="register"  <?php if($row_user['privacy_register']==1){ ?> checked="checked" <?php } ?> value="1" /> Yes
             <input type="radio" name="register" id="register"  <?php if($row_user['privacy_register']==0){ ?> checked="checked" <?php } ?> value="0" /> No
                       </td>
    </tr>
             
					<tr>
	<td colspan="2"><input style="display:none;" type="text" name="idd" id="idd" value="<?php echo $_GET['id']; ?>"  ><input type="hidden" name="action" value="model" />
             <input type="hidden" name="module" value="customers" /></td></tr>
					
					<tr>
	<td colspan="2"><input type="submit" name="save_cat" id="save_cat" value="Submit" class="form_btn" ></td></tr>
	
</table>
</form>
</div>
</div>
</div>
	
    <?php
    }
	
	

}
?>