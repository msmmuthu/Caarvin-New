<?php
class report extends config{

	
	
	public function business(){ ?>
    
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css"> 
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.11/css/dataTables.bootstrap.min.css" type="text/css" media="all">
    


<script src="//code.jquery.com/jquery-1.12.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.11/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.11/js/dataTables.bootstrap.min.js"></script>
    <script>
	$(document).ready(function() {
    $('#example').DataTable();
} );



	</script>
    
	
	   
		
		<div style="padding:2%;">
        
        <div class="nav">
		<h4>Business Reports</h4>
		</div>
		
		
	
    
	<table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
  <thead>
        <tr>
   <th><strong>Date</strong></th>
    <th><strong>Location</strong></th>
   <th><strong>Introducer ID</strong></th>
	<th><strong>Customer ID</strong></th>
	<th><strong>Model</strong></th>
    <th><strong>Purpose</strong></th>
   <th><strong>Scheme</strong></th>
   <th><strong>Amount</strong></th>
    <th><strong>Send by</strong></th>
   <th><strong>Sending Details</strong></th>
   <th><strong>Cash ID</strong></th>
    <th><strong>Received by</strong></th>
   <th><strong>Allocate qty</strong></th>
   <th><strong>Total Allocate qty</strong></th>
    <th><strong>Used qty</strong></th>
   <th><strong>Balance qty</strong></th>
  </tr>
  </thead>
  
  
  <tbody>
            
            <?php
            $query = mysqli_query($this->mysqlConfig(),"select * from pic_scheme_user");
  $no = 1;
  while($row = mysqli_fetch_object($query)){
  $id_agent = $row->pic_user_id;
  
  $query_user = mysqli_query($this->mysqlConfig(),"SELECT * FROM `pic_user` WHERE `user_id`=$id_agent");
  $row_user = mysqli_fetch_object($query_user);
  
  ?>
  
  <tr>
    <td><?php echo date('d-m-Y', strtotime($row->scheme_purchased_date)); ?></td>
    <td><?php echo $row_user->user_town; ?>,<?php echo $row_user->user_taluk; ?>,<?php echo $row_user->user_city; ?> District</td>
    <td><?php //echo $row['user_email']; ?></td>
	<td>PACID<?php echo $row_user->user_id; ?></td>
    <td><?php //echo $row_user->user_id; ?></td>
     <td><?php echo $row->scheme_purpose; ?></td>
    <td><?php echo $row->pic_scheme_name; ?></td>
    <td><?php echo $row->cost_scheme; ?></td>
    
    <td><?php echo $row->payment_method; ?></td>
    <td><?php //echo $row->pic_scheme_name; ?></td>
    <td><?php echo $row->scheme_cash_id; ?></td>
    
    <td><?php echo $row->payment_status; ?></td>
    <td><?php echo $row->total_ads; ?></td>
    <td><?php echo $row->total_ads; ?></td>
    
    <td><?php echo $row->total_ads-$row->pic_scheme_balance_qty; ?></td>
    <td><?php echo $row->total_ads-($row->total_ads-$row->pic_scheme_balance_qty); ?></td>
    
  </tr>
  
  <?php
    } ?>
    </tbody>        

</table>

</div>
	
    <?php
    }
	
	public function reports(){  ?>
    
<div class="content">

    <div class="nav">
    Customer Management Privacy Setting
    </div>
    
    <div class="main" style="padding:25px;height:50%;" >
        <div  style="padding:10px; width:100%; border-color:#fed82e;border-style:dashed;border-width:thin;border-radius:5px; float:left; ">
             <ul class="ico-admincp">
                 <li>
                    <a onclick="report_business();"><i style="font-size:50px;" class="fa fa-file-o"></i><div>BUSINESS STATEMENTS</div></a>
                 </li>
                 <li>
                    <a onclick="report_master();"><i style="font-size:50px;" class="fa fa-file-o"></i><div>MASTER STATEMENTS</div></a>
                 </li>
                 <li>
                    <a onclick="report_business();"><i style="font-size:50px;" class="fa fa-file-o"></i><div>BUSINESS REPORTS</div></a>
                 </li>
             </ul>
        </div>
    </div>
    
</div>
    
    <?php
	}
}
?>
