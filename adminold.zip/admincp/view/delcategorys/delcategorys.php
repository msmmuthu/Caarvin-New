<?php
class delcategorys extends config{

	public function delcat(){
		$idd=$_GET['id'];
$customer_query = mysqli_query($this->mysqlConfig(),"delete from pic_categories where categories_id='$idd' ");	
$customer_query1 = mysqli_query($this->mysqlConfig(),"delete from pic_categories_fields where fields_categories_id='$idd' ");
}
}
?>
<script type="text/javascript">
 window.location="index.php?action=view&module=privacy";
           </script>