<?php
class settings extends config{

	
	
	public function change_password(){
	?>
	
    <div class="content">
		
		<div class="nav">
		Change Password
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="padding:10px; width:100%;height:125%;">
       <?php
	   $query=mysqli_query($this->mysqlConfig(),"SELECT * FROM pic_admin WHERE admin_id=".$_SESSION['userid']."");
	   $row = mysqli_fetch_array($query);
	   
	   ?>
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" name="change_password_form" id="change_password_form" method="post" >
         <input type="hidden" name="action" value="model" />
             <input type="hidden" name="module" value="settings" />
             <div style="position:relative; float:left; width:50%; ">
		  <table border="0">
            <tr>
              <td height="38">Admin Username</td>
              <td colspan="3">
                <input type="text" name="usr_name" id="usr_name" class="form_txt" value="<?php echo $row['admin_username']; ?>" disabled />              </td>
            </tr>
            <tr>
              <td height="38">Admin Password</td>
              <td colspan="3">
                <input type="text" name="usr_pass" id="usr_pass" class="form_txt" value="<?php echo $row['admin_password']; ?>" disabled />              </td>
            </tr>
            <tr>
              <td height="38">Change Password</td>
              <td colspan="3">
              <input class="form_txt" title="Password must contain at least 6 characters, including UPPER/lowercase and numbers" type="password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" name="change_pass" onchange="
  this.setCustomValidity(this.validity.patternMismatch ? this.title : '');
  if(this.checkValidity()) change_password_form.change_pass.pattern = this.value;
">
</td>
            </tr>
            <tr>
              <td height="34">Confirm Password</td>
              <td colspan="3">
              <input class="form_txt" title="Please enter the same Password as above" type="password" required pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}" name="confirm_pass" onchange="
  this.setCustomValidity(this.validity.patternMismatch ? this.title : '');
">
              </td>
            </tr>
             
           
           

            
           <tr>
              <td height="34"></td>
              <td colspan="3">
              <input type="reset" name="reset" id="reset" value="Reset"  class="form_btn"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <input type="submit" name="save_password" id="save_password" value="Submit" class="form_btn" />                  </td>
            </tr>
          </table>
          
          </div>
         </form>
          </div>
  </div>
		
</div>
	<?php
    }
    
   
	


}
?>