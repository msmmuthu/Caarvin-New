<?php
class categorys extends config{

	public function form1(){
		$idd= $_GET['id'];
$customer_query1 = mysqli_query($this->mysqlConfig(),"select * from pic_categories where categories_id='$idd' ");
while($row1 = mysqli_fetch_array($customer_query1)){
	?>
	
    <div class="content">
		
		<div class="nav">
		View Category Management
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="padding:10px; width:100%;height:125%;">
        <form action="" name="cat_form" id="cat_form" method="post" >
         <input type="hidden" name="action" value="model" />
             <input type="hidden" name="module" value="category" />
             <div style="position:relative; float:left; width:50%; ">
		  <table border="0">
            <tr>
              <td height="38">Category Name</td>
              <td colspan="3">
                <input type="text" name="cat_name" id="cat_name" class="form_txt" value="<?php echo $row1['categories_name']; ?>" readonly/>              </td>
            </tr>
            <tr>
              <td height="34"> Description</td>
              <td colspan="3"><input type="text" name="cat_desc" id="cat_desc" class="form_txt" value="<?php echo $row1['categories_desc']; ?>" readonly /></td>
            </tr>
            <tr>
              <td height="34">Choose Images</td>
              <td colspan="3">
               
                <div  style="position:relative; float:left;">
<input type="text" name="cat_pic" class="form_txt" id="cat_pic" value="<?php echo $row1['categories_image']; ?>" readonly />
                
                </div>
                <div id="cat_images" style="font-size:30px; float:left; position:relative; padding-left:10px; "></div>              </td>
            </tr>
            <tr>
              <td height="34">Root Category</td>
              <td colspan="3">
                <label>
                  <input type="radio" name="cat_root" value="1" id="cat_root_0" <?php echo ($row1['categories_parent']== '1') ?  "checked" : "" ;  ?> />
                  Parent</label>
               
                <label>
                  <input type="radio" name="cat_root" value="0" id="cat_root_1" <?php echo ($row1['categories_sub']!= '0') ?  "checked" : "" ;  ?> />
                  Sub</label>              </td>
            </tr>
            <tr >
            <td >Choose Sub Category</td>
              <td id="sub_cat_div" colspan="3" >              </td>
           </tr>
           
            <tr>
              <td height="34" rowspan="2">Page Layout</td>
              <td align="center" valign="middle"><input type="radio" name="cat_layout" value="1-col" id="cat_layout_0" style="margin-top: -42px;" />
                <img  src="css/images/1-col.png" width="75" height="75" /> </td>
              <td align="center" valign="middle"><input type="radio" name="cat_layout" value="2-col" id="cat_layout_1" style="margin-top: -42px;" />
                <img src="css/images/2-col.png" alt="" width="75" height="75" /> </td>
              <td align="center" valign="middle"><input type="radio" name="cat_layout" value="2-row" id="cat_layout_2" style="margin-top: -42px;" />
                <img src="css/images/2-row.png" alt="" width="75" height="75" /></td>
            </tr>
            <tr>
              <td><label>
                <div align="center">1 Column &amp; 1 Row</div>
              </label>
              <label></label></td>
              <td><label> 
                <div align="center">2 Column &amp; 1 Row</div>
              </label>
                <label> </label></td>
              <td><label>
                <div align="center">1 Column &amp; 2 Row</div>
              </label></td>
            </tr>
            <tr>

              <td height="34">&nbsp;</td>
              <td colspan="3">&nbsp;</td>
            </tr>




            <tr >
            <td >TextBox <span style="font-size:12px;">(Title1,Title2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="text_title" id="text_title" class="form_txt" style="width:85%;" placeholder="Title1,Title2,.." /> 
               <input type="text" name="text_prior" id="text_prior" class="form_txt" style="width:13%;" />
                            </td>
           </tr>
           <tr >
            <td >Numeric <span style="font-size:12px;">(Title1,Title2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="num_title" id="num_title" class="form_txt" style="width:85%;" placeholder="Title1,Title2,.." />  
               <input type="text" name="num_prior" id="num_prior" class="form_txt" style="width:13%;" />
                           </td>
           </tr>
           
            <tr>
              <td >&nbsp;</td>
              <td colspan="3" >&nbsp;</td>
            </tr>
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title1" id="drop_title1" class="form_txt" style="width:85%;" /> 
               <input type="text" name="drop_title1_prior" id="drop_title1_prior" class="form_txt" style="width:13%;" />
                            </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value1" id="drop_value1" class="form_txt"  placeholder="Value1,Value2,.." />              </td>
           </tr>
           
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
           
            <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title2" id="drop_title2" class="form_txt" style="width:85%;"/>
               <input type="text" name="drop_title2_prior" id="drop_title2_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value2" id="drop_value2" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
          </table>
          </div>
          <div style="position:relative; float:right; width:45%; padding-left:5%; ">
          <table>
           
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
           <tr >           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title3" id="drop_title3" class="form_txt" style="width:85%;" />
               <input type="text" name="drop_title3_prior" id="drop_title3_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value3" id="drop_value3" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title4" id="drop_title4" class="form_txt"  style="width:85%;"/>
               <input type="text" name="drop_title4_prior" id="drop_title4_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value4" id="drop_value4" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title5" id="drop_title5" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title5_prior" id="drop_title5_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value5" id="drop_value5" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           
           
           
           
           
           <tr >
             <td >&nbsp;</td>
             <td colspan="3" >&nbsp;</td>
           </tr>
           <tr >
            <td >Search Tags Title<span style="font-size:12px;"></span></td>
              <td colspan="3" >
               <input type="text" name="search_title" id="search_title" class="form_txt" value="<?php echo $row1['cat_search_title']; ?>" readonly/>              </td>
           </tr>
           <tr >
            <td >Search Tags Limit<span style="font-size:12px;"></span></td>
              <td colspan="3" >
               <input type="text" name="search_limit" id="search_limit" class="form_txt" value="<?php echo $row1['cat_search_limit']; ?>" readonly/>              </td>
           </tr>
           <tr >
             <td >&nbsp;</td>
             <td colspan="3" >&nbsp;</td>
           </tr>
           <tr >
            <td >Contact Type</td>
              <td colspan="3" >
<input type="text" name="contact_type" id="contact_type" class="form_txt" value="<?php echo $row1['categories_contact_type']; ?>" readonly/> 
          
          </td>
           </tr>
           <tr >           </tr>
           <tr >
            <td >User Type Privacy</td>
              <td colspan="3" >
<input type="text" name="user_type[]" id="user_type[]" class="form_txt" value="<?php echo $row1['user_type']; ?>" readonly/>
              
          </td>
           </tr>
          
          </table>
          
          </div>
         </form>
          </div>
  </div>
		
</div>
	<?php
    }
	}
	

}
?>



