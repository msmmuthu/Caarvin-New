<div class="footer">

<div class="left">
Powered By <strong>AboWin</strong>
</div>

</div>
<script>
function updateAjax(e){
var valueField= e.value;
var idField= e.id; 
var nameField= e.name; 

postdata = {
'action' : "model",
'module' : "customers",
'post' : nameField,
'id' : idField,

}


$.post("index.php",postdata,function(data){
$('#tr_'+idField).html(data);														  
});

}

function updateAjaxAds(e,posted){
	var valueField= e.value;
	var idField= e.id; 
	var nameField= e.name; 
	
	postdata = {
	'action' : "model",
	'module' : "Ads",
	'val' : nameField,
	'id' : idField,
	'post' : posted,
	}
	
	$.post("index.php",postdata,function(data){
	//$('#tr_'+idField).html(data);														  
	});

}
function updateAjaxAds2(e,posted){
	var valueField= e.value;
	var idField= e.id; 
	
	postdata = {
	'action' : "model",
	'module' : "Ads",
	'id' : idField,
	'post' : posted,
	}
	
	
	$.post("index.php",postdata,function(data){
	//$('#tr_'+idField).html(data);														  
	});

}
	</script>