<?php
class home{

public function index(){
	?>
	<div class="content">
		
		<div class="nav">
		Dashbord
       
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="background-color:#CCCCCC; padding:10px; width:95%; border-color:#fed82e;border-style:dashed;border-width:thin;border-radius:5px;">
       Welcome to Control Panel
       
   
	

</div>
</div>
</div>
<?php
	}

	

}
?>



