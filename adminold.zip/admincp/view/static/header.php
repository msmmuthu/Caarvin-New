<?php
$logout = new indexcontroller();
?>
<?php
$servername = "localhost";
		$username = "devavv";
		$password = "vvinWIN@2019";
		$dbname = "abocarz";

$conn = mysqli_connect($servername, $username, $password, $dbname);
?>

<div class="header">
    
    <div class="main">
        <div class="logo">
          
          <div class="left">
          <img src="css/images/logo.png"> <h4 style="color:#000000;padding: 2px;">
           Control Panel
            </h4>
          </div>
          <div class="left" style="padding:5px;margin-top:31px;">
             
            </div>
             <div class="right" align="right">
              <p style="font-size:15px;">
			  <?php echo date("D,d");?>th <?php echo date("M,Y"); ?>
              </p>
              
              <a href="index.php?action=config&module=session"> Logout </a>
            
            </div>
        </div>
        <?php
	$usertype_query = mysqli_query($conn,"select * from pic_admin where admin_id=".$_SESSION['userid']."");
	$row = mysqli_fetch_array($usertype_query);
	?>
		  
      <div class="menu">
     
        <?php if(strpos($row['admin_sets'], 'fields') !== false or strpos($row['admin_sets'], 'category') !== false){ ?>
        <a href="index.php?action=view&module=category&post=list">Category Management</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'Ads') !== false){ ?>
        <a href="index.php?action=view&module=Ads&post=list">Ads</a>
        <?php } ?>
         <?php if(strpos($row['admin_sets'], 'likes') !== false){ ?>
        <a href="index.php?action=view&module=likes&post=list">Likes</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'customer') !== false){ ?>
        <a href="index.php?action=view&module=customer">Customers</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'scheme') !== false){ ?>
        <a href="index.php?action=view&module=scheme&post=request_list">Scheme</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'user') !== false){ ?>
        <a href="index.php?action=view&module=user&post=usertype">User Type</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'report') !== false){ ?>
        <a href="index.php?action=view&module=report&post=listing">Reports</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'administrator') !== false){ ?>
        <a href="index.php?action=view&module=administrator&post=administrator">Administrator</a>
        <?php } ?>
        <?php if(strpos($row['admin_sets'], 'settings') !== false){ ?>
        <a style="border:none;width: 88px;" href="index.php?action=view&module=settings">Settings</a>
        <?php } ?>
        </div>
     </div>

</div>
