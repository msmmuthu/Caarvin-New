<?php
class category extends config{

public function listing(){
	?>
	<div class="content">
		
		<div class="nav">
		Category Management
        <a  style="float:right;" class="btn_sub" href="index.php">Listing</a>
   		<a style="float:right;" class="btn_sub_active" href="index.php?action=view&module=category">Add New</a>
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="background-color:#CCCCCC; padding:10px; width:95%; border-color:#fed82e;border-style:dashed;border-width:thin;border-radius:5px;">
        <a href="cat_export.php">Export Category</a> &nbsp;&nbsp;&nbsp;&nbsp;
        <a href="cat_field_export.php">Export Category Fields</a>
   
	<table id="example" class="table table-striped table-bordered">
  <thead>
  <tr>
   
    <th width="20%"><strong>CATEGORY</strong></td>
    <th width="30%"><strong>DESCRIPTION</strong></td>
    <th width="10%" align="center"><strong>Sub Category</strong></td>
    <th width="30%" align="center"><strong>Action</strong></td>
    <th width="30%" align="center"><strong>Action</strong></td>
    <th width="30%" align="center"><strong>Action</strong></td>
    </tr>
    </thead>
    <tbody>
  <?php
   //$subcat_query = mysqli_query($this->mysqlConfig(),"SELECT * FROM `pic_categories` where `categories_status`= 1 and `categories_parent`=0 and categories_sub=".$categories_id."");
 if($_REQUEST['post']=="sub"){
 
 $catsubid = $_REQUEST['catid'];
 
 $str = "and categories_sub!=0 and categories_sub=".$catsubid."";
 echo $str;
 }
 else{
 
  $str = "and `categories_parent`=1"; 
 
 }

  
  $cat_query = mysqli_query($this->mysqlConfig(),"SELECT * FROM `pic_categories` where `categories_status`= 1 ".$str." ORDER BY `categories_name` DESC");
  
  while($row = mysqli_fetch_array($cat_query)){
  $id_agent = $row['categories_status'];
  $categories_id = $row['categories_id'];
  
  $subcat_query = mysqli_query($this->mysqlConfig(),"SELECT * FROM `pic_categories` where `categories_status`= 1 and categories_sub = $categories_id");
  $subcat_count = mysqli_num_rows($subcat_query);
  
  ?>
  <tr>
    <td><?php echo $row['categories_name']; ?></td>
    <td><?php echo $row['categories_desc']; ?></td>
    <td width="15%" align="center"><div class="link_href"><a href="index.php?action=view&module=category&catid=<?php echo $row['categories_id']; ?>&post=sub"><strong><?php echo $subcat_count; ?></strong> </a></div></td>
    <td width="8%" align="center"><div class="link_href"><a href="index.php?action=view&module=fields&catid=<?php echo $row['categories_id']; ?>&post=edit">Edit</a></div></td>
    <td width="8%" align="center"><?php if($row['categories_hidden']==1){ ?> <div class="link_href"><a href="index.php?action=model&module=category&id=0&post=hidden&catid=<?php echo $row['categories_id']; ?>">Hide</a></div>  <?php } else { ?> <div class="link_href"><a href="index.php?action=model&module=category&id=1&post=hidden&catid=<?php echo $row['categories_id']; ?>">Show</a></div><?php } ?></td>
    <td width="8%" align="center"><?php if($row['categories_status']==1){ ?> <div class="link_href"><a href="index.php?action=model&module=category&catid=<?php echo $row['categories_id']; ?>&post=delete">Delete</a></div>  <?php } ?></td>
  </tr>
  
  <?php
  
 
}
  ?>
  </tbody>
</table>

</div>
</div>
</div>
<?php
	}

	public function form(){
	?>
	
    <div class="content">
		
		<div class="nav">
		Category Management
         <a  style="float:right;" class="btn_sub_active" href="index.php">Listing</a>
   		<a style="float:right;" class="btn_sub" href="index.php?action=view&module=category">Add New</a>
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="padding:10px; width:100%;height:125%;">
        <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" name="cat_form" id="cat_form" method="post" >
         <input type="hidden" name="action" value="model" />
             <input type="hidden" name="module" value="category" />
             <div style="position:relative; float:left; width:50%; ">
		  <table border="0">
            <tr>
              <td height="38">Category Name</td>
              <td colspan="3">
                <input type="text" name="cat_name" id="cat_name" class="form_txt" />              </td>
            </tr>
            <tr>
              <td height="34"> Description</td>
              <td colspan="3"><input type="text" name="cat_desc" id="cat_desc" class="form_txt" /></td>
            </tr>
            
            <tr>
              <td height="34">Root Category</td>
              <td colspan="3">
                <label>
                  <input type="radio" name="cat_root" value="1" id="cat_root_0"  onchange="cat_sub();" />
                  Parent</label>
               
                <label>
                  <input type="radio" name="cat_root" value="0" id="cat_root_1" onchange="cat_sub();" />
                  Sub</label>              </td>
            </tr>
            <tr >
            <td >Choose Sub Category</td>
              <td id="sub_cat_div" colspan="3" >              </td>
           </tr>
           
            
            




            <tr >
            <td >TextBox <span style="font-size:12px;">(Title1,Title2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="text_title" id="text_title" class="form_txt" style="width:85%;" placeholder="Title1,Title2,.." /> 
               <input type="text" name="text_prior" id="text_prior" class="form_txt" style="width:13%;" />                            </td>
           </tr>
           <tr >
            <td >Numeric <span style="font-size:12px;">(Title1,Title2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="num_title" id="num_title" class="form_txt" style="width:85%;" placeholder="Title1,Title2,.." />  
               <input type="text" name="num_prior" id="num_prior" class="form_txt" style="width:13%;" />                           </td>
           </tr>
           
            <tr>
              <td >&nbsp;</td>
              <td colspan="3" >&nbsp;</td>
            </tr>
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title1" id="drop_title1" class="form_txt" style="width:85%;" /> 
               <input type="text" name="drop_title1_prior" id="drop_title1_prior" class="form_txt" style="width:13%;" />                            </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value1" id="drop_value1" class="form_txt"  placeholder="Value1,Value2,.." />              </td>
           </tr>
           
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
           
            <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title2" id="drop_title2" class="form_txt" style="width:85%;"/>
               <input type="text" name="drop_title2_prior" id="drop_title2_prior" class="form_txt" style="width:13%;" />                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value2" id="drop_value2" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
              <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title3" id="drop_title3" class="form_txt" style="width:85%;" />
               <input type="text" name="drop_title3_prior" id="drop_title3_prior" class="form_txt" style="width:13%;" />                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value3" id="drop_value3" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title4" id="drop_title4" class="form_txt"  style="width:85%;"/>
               <input type="text" name="drop_title4_prior" id="drop_title4_prior" class="form_txt" style="width:13%;" />                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value4" id="drop_value4" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
          </table>
          </div>
          <div style="position:relative; float:right; width:45%; padding-left:5%; ">
          <table>
           
           <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
           <tr >           </tr>
             
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title5" id="drop_title5" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title5_prior" id="drop_title5_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value5" id="drop_value5" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
            <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title6" id="drop_title6" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title6_prior" id="drop_title6_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value6" id="drop_value6" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
            <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title7" id="drop_title7" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title7_prior" id="drop_title7_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value7" id="drop_value7" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
            <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title8" id="drop_title8" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title8_prior" id="drop_title8_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value8" id="drop_value8" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
            <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title9" id="drop_title9" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title9_prior" id="drop_title9_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value9" id="drop_value9" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
            <tr >
            <td >&nbsp;</td>
              <td colspan="3" >&nbsp;              </td>
           </tr>
             <tr >
            <td >Drop Down Title</td>
              <td colspan="3" >
               <input type="text" name="drop_title10" id="drop_title10" class="form_txt" style="width:85%;"/> 
                <input type="text" name="drop_title10_prior" id="drop_title10_prior" class="form_txt" style="width:13%;" />
                             </td>
           </tr>
           <tr >
            <td >Value <span style="font-size:12px;">(Value1,Value2,..)</span></td>
              <td colspan="3" >
               <input type="text" name="drop_value10" id="drop_value10" class="form_txt" placeholder="Value1,Value2,.."/>              </td>
           </tr>
           
           
           
           
           <tr >
             <td >&nbsp;</td>
             <td colspan="3" >&nbsp;</td>
           </tr>
           
           
           
           <tr >
            <td >Contact Type</td>
              <td colspan="3" >
          <input type="radio" name="contact_type" id="contact_type" value="call" checked> &nbsp; Call Contact </br>
          <input type="radio" name="contact_type" id="contact_type" value="form"> &nbsp; Form Contact </br>
          <input type="radio" name="contact_type" id="contact_type" value="register"> &nbsp; register Contact </br>
          <input type="radio" name="contact_type" id="contact_type" value="appointment"> &nbsp; Appointment Contact </br>
          </td>
           </tr>
           <tr >           </tr>
           <tr >
            <td >User Type Privacy</td>
              <td colspan="3" >
              <?php
			  $usertype_query = mysqli_query($this->mysqlConfig(),"select * from pic_user_type");
			  $g = 1;
			 while($row = mysqli_fetch_array($usertype_query)){
			  ?>
          <input type="checkbox" name="user_type[]" id="user_type[]" value="<?php echo $row['user_type']; ?>" > &nbsp; <?php echo $row['user_type']; ?> </br>
		  
          <?php $g =$g+1; }?>
          </td>
           </tr>
           <tr>
              <td height="34"></td>
              <td colspan="3">
              <input type="reset" name="reset" id="reset" value="Reset"  class="form_btn"/>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <input type="submit" name="save_cat" id="save_cat" value="Submit" class="form_btn" />                  </td>
            </tr>
          </table>
          
          </div>
         </form>
          </div>
  </div>
		
</div>
	<?php
    }
	
	public function select(){
	?>
    
	 
             <select name="sub_category" id="sub_category" class="form_txt"  size="5" >
               
             <option value="0">Select</option>
             <?php
			 if($_REQUEST['step']=="1"){
			 $str = "categories_parent=1";
			 }
			 elseif($_REQUEST['step']=="2"){
			 $str = "categories_sub=".$_REQUEST['sub_category_id']."";
			 }
			 $sub_cat_query = mysqli_query($this->mysqlConfig(),"select * from pic_categories WHERE ".$str." and categories_status=1");
			 while($row = mysqli_fetch_array($sub_cat_query)){
			 ?>
              <option onDblClick="cat_sub_select();" value="<?php echo $row['categories_id'] ?>"><?php echo $row['categories_name'] ?></option>
              <?php
			  }
			  ?>
             </select>
              
           
     
		
	<?php
	}

}
?>



