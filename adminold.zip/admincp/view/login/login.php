    <div style="background-color:#FFFFFF; border-radius: 7px; border:1px solid #797979; color:#000000; position:relative; width:310px; margin-left: auto; margin-right: auto; margin-bottom:auto; margin-top:100px;">
	 
      <table width="100%">
        <tr>
          
          <td width="71%"><div align="center"><h3 style="padding-top:10px;"><img src="css/images/logo.png"> <p>Administrator<p></h3></div></td>
        </tr>
		<tr>
          
          <td width="71%">&nbsp;</td>
        </tr>
      </table>
   

  
   
  
     <form id="login" name="login" method="post" action="<?php echo $_SERVER["PHP_SELF"]; ?>">
	 
     <table width="100%" >
       <tr>
         <td colspan="2"><div align="center"><span class="style9">Username</span></div></td>
         <td colspan="3"><label>
         
             <div align="left">
             <input type="hidden" name="action" value="model" />
             <input type="hidden" name="module" value="login" />
			  <input type="text" name="username" id="username" class="username" placeholder="Enter the Username" style="height: 30px;  width:auto;font-size:13px;font-family:AmbleRegular; font-weight:bold;" value="">
             </div>
         </label></td>
       </tr>
       <tr>
         <td colspan="2">&nbsp;</td>
         <td colspan="3">&nbsp;</td>
       </tr>
       <tr>
         <td colspan="2"><div align="center"><span class="style9">Password</span></div></td>
         <td colspan="3"><label>
           
             <div align="left">
			 <input type="password" name="pass" id="pass" class="pass" placeholder="Enter the Password" style="height: 30px;  width:auto;font-size:13px;font-family:AmbleRegular; font-weight:bold;" value="">
             </div>         </td>
       </tr>
       <tr>
         <td colspan="2">&nbsp;</td>
         <td colspan="3">&nbsp;</td>
       </tr>
       <tr style=" height:70px;">
         <td width="10%">&nbsp;</td>
         <td> <input style="border-radius: 4px;" type="submit" name="submit_login" id="submit_login" value="Submit" class="submit" />   </td>
         <td>&nbsp;</td>
         <td><input style="float:right;border-radius: 4px;" type="reset" name="clear" id="clear" value="Clear"   class="reset" /></td>
         <td width="10%">&nbsp;</td>
       </tr>
     </table>
	 
	 
	 </form>
	 <div id="error_msg" align="center" style="height: 18px; color: rgb(255, 255, 255); font-size: 15px; padding: 15px;   font-family:AmbleRegular; background-color: rgb(100, 0, 0);  display:none;">
	 Invalid Login Details
	 </div>
	 
   </div>
   
	