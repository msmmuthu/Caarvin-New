<?php
ob_start();
class adsb extends config{


	
	
	public function categoryList(){ 
$filename="Ads.xls"; 
header("Content-Disposition: attachment; filename='$filename' ");
header("Content-Type: application/vnd.ms-excel");
?>
	
	    <div class="content">
		
		<div class="nav">
		Ads Management
		</div>
		
		<div class="main" style="padding:25px;" >
        
       <div  style="background-color:#CCCCCC; padding:10px; width:100%; border-color:#fed82e;border-style:dashed;border-width:thin;border-radius:5px;">
	<style type="text/css">
   #rows tr>th{
	padding:5px;
	border-style:solid;
	border-width:thin;
	border-color:#999999;
   }
   #rows tr>td{
	padding:5px;
	border-style:solid;
	border-width:thin;
	border-color:#999999;
   }
   a{
	text-decoration:none;
	}
   </style>
    
	
  <?php
 //$filename = "Ads.xls"; // File Name
// Download file
//header("Content-Disposition: attachment; filename=\"$filename\"");
//header("Content-Type: application/vnd.ms-excel"); ?>
  <table id="rows" width="100%" border="0">
  <tr>
    <td width="5%" align="center"><strong>No</strong></td>
    <td width="30%" align="center"><strong>Ads_id</strong></td>
    <td width="10%" align="center"><strong>Ads_title</strong></td>
    <td width="10%" align="center"><strong>Ads_discription</strong></td>
    <td width="20%"  align="center"><strong>Ads_postdate</strong></td>
	<td width="20%"  align="center"><strong>Ads_user_email</strong></td>
  </tr>
  <?php
  $customer_query = mysqli_query($this->mysqlConfig(),"select * from pic_addpost");
  $no = 1;
  while($row = mysqli_fetch_array($customer_query)){?>
  
  <tr>
    <td align="center"><?php echo $no; ?></td>
    <td align="center"><?php echo $row['pic_ads_id']; ?></td>
    <td align="center"><?php echo $row['pic_title']; ?></td>
   
    <td align="center"><?php echo $row['pic_discription']; ?></td>
    <td align="center"><?php echo $row['pic_postdate']; ?></td>
    <td align="center"><?php echo $row['pic_user_email']; ?></td>
    
  </tr>
  
  
 <?php 
 $no++;
 }
  ?>
</table>
  

</div>
</div>
</div>
	
    <?php
    }
	}
ob_end_flush();
?>
