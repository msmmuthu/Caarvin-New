<?php
class registration extends config{ 

	public function registrationSaveModel(){
	
		
		echo $_POST['first_name'];
		
		//mysqli_query($this->mysqlConfig(),"insert into ");
	
	}

}
?>
