<?php
class login extends config{

public function verify(){

		if(!empty($_POST['username'])){
		
			$id=$_POST['username'];
			$id=mysqli_real_escape_string($this->mysqlConfig(),$id);
			$pw=$_POST['pass'];
			
			$query=mysqli_query($this->mysqlConfig(),"SELECT * FROM pic_admin WHERE admin_username='$id' AND admin_password='$pw'");
			
			$main = new indexcontroller();
			
			if(mysqli_num_rows($query)==1){
			
				$row = mysqli_fetch_array($query);
				
				require("config/session/session.php");
				$session = new session();
				$session -> create($row['admin_id'],$row['admin_username']);
				
				$main->dashboard();
				
			}
			else{
			
				print "<script>";
				print " self.location='index.php';";
				print "</script>";
				
				$main->login();
			}
		
		}
	
	}

}

?>