<?php

class location{

	public function taluk(){ ?>
	<div class="col-2">
                                    
                                    
                                    <div class="rows">
                                    <select style="width:100%;"  name="taluk_select" id="taluk_select" >
				<option value="0" selected>Select Taluk</option>
				<?php
				
				$location_query = mysqli_query($this->mysqlConfig(),"select DISTINCT city2  from pic_geometric where city1='".$_POST['value_city']."' order by lan,lon ASC");
				
				while($row = mysqli_fetch_object($location_query)){
				?>
				
				<option  value="<?php echo $row->city2; ?>"> <?php echo $row->city2; ?> </option>
				
				<?php } ?>
				</select>

                                        

                                    </div>
                                  
                                    <div class="col-2">
                                    
                                    <div class="rows">
                                    <input  style="width:97%;" type="text" name="town"  required placeholder="Enter Town Name.." /><br/>
                                    <input style="width:100%;" type="submit" name="setlocation"  value="Set Location"  />
                                    </div>
                                </div>
                                </div>
    <?php
	}
	
	public function talukAll(){ ?>
	<div class="col-2">
                                    <div class="search-title">Select Taluk *</div>
                                    <div class="space_10"></div>
                                    <div class="rows">
                                    <select class="form_txt"  name="taluk_select" id="taluk_select" >
				<option value="0" selected>Select</option>
				<?php
				
				$location_query = mysqli_query($this->mysqlConfig(),"select DISTINCT city2  from pic_geometric where city1='".$_POST['value_city']."' order by lan,lon ASC");
				
				while($row = mysqli_fetch_object($location_query)){
				?>
				
				<option  value="<?php echo $row->city2; ?>"> <?php echo $row->city2; ?> </option>
				
				<?php } ?>
				</select>

                                        

                                    </div>
                                    <div class="space_10"></div>
                                    <div class="col-2">
                                    
                                    <div class="rows">
                                    <input type="text" name="town" class="form_txt" required placeholder="Town" />
                                    

                                        

                                    </div>
                                </div>
                                </div>
    <?php
	}
		
}
?>