<?php
session_start();

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Administration - PIC</title>
</head>

<body>
<link href="css/style.css" type="text/css" rel="stylesheet">
<link href="css/font-awesome.min.css" type="text/css" rel="stylesheet">

<script src="js/jquery-1.7.2.min.js"></script>
<script src="js/script.js"></script>

	 


<link rel="stylesheet" href="css/custom.css" type="text/css" media="all">  
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.9/css/jquery.dataTables.min.css"/>
<!--<link rel="stylesheet" href="css/dataTables.bootstrap.min.css" type="text/css" media="all">-->

<script src="js/jquery-1.12.0.min.js"></script>
<script src="js/jquery.dataTables.min.js"></script>
<script src="js/dataTables.bootstrap.min.js"></script>

<script>
$(document).ready(function() {
//$('#example').DataTable();
} );

$(document).ready(function () { 
    var oTable = $('#example').dataTable();

    var allPages = oTable.fnGetNodes();

    $('body').on('click', '#selectAll', function () {
        if ($(this).hasClass('allChecked')) {
            $('input[type="checkbox"]', allPages).prop('checked', false);
        } else {
            $('input[type="checkbox"]', allPages).prop('checked', true);
        }
        $(this).toggleClass('allChecked');
    })
});
</script>


<?php
include "config/config.php";



		
		
		require("controller/index.php");
		$indexcontroller = new indexcontroller();
		$indexcontroller->index();
		
	

		


//$indexcontroller = new index();
?>


</body>
</html>
