<?php
class session{


public function create($cid,$cus_rank){

	$_SESSION['userid'] = $cid;
	$_SESSION['admin'] = $cus_rank;
	

}


public function clear(){

	$_SESSION['userid'] = "";
	$_SESSION['admin'] = "";
	

}


}
?>